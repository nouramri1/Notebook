public class Link {
    private String type;
    private String link;
}
